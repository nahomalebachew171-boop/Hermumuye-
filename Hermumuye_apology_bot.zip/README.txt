HERMUMUYE APOLOGY PROJECT

1. Open index.html in a browser to test the interactive page.
2. Upload index.html to any static web host (for example GitHub Pages, Netlify, Vercel, or another host).
3. Copy the public webpage URL.
4. Replace YOUR_WEBPAGE_URL in email.html with that URL.
5. Replace YOUR_EMAIL@example.com in index.html with the email address you want the gift button to contact.
6. Send the email using the email.html design or copy its text into your email client.

The page intentionally does not track her location, collect personal data, or force an answer.
